class Brew{
  final String name;
  final String sugar;
  final int strength;

  Brew({this.name, this.sugar, this.strength});
}