import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter_with_firebase/models/brew.dart';
import 'package:flutter_with_firebase/models/user.dart';
import 'package:provider/provider.dart';

class DatabaseService{
  // collection reference : a collection is a set that contains record as documents

  final String uid;
  DatabaseService({this.uid});
  final CollectionReference brewCollection = Firestore.instance.collection('brews');

  Future updateUserData(String sugar, String name, int strength) async{
    return await brewCollection.document(uid).setData({
      'sugar': sugar,
      'name': name,
      'strength': strength,
    });
  }

  //brew list from snapshot
  List<Brew> _brewListFromSnapshot(QuerySnapshot snapshot) {
    return snapshot.documents.map((doc){
      return Brew(
        name: doc.data['name'] ?? '',
        strength: doc.data['strength'] ?? 0,
        sugar: doc.data['sugar'] ?? '0',
      );
    }).toList();
  }
  // userdata from snapshot

  UserData _userDataFromSnapshot(DocumentSnapshot snapshot){
    return UserData(
      uid: uid,
      name: snapshot.data['name'],
      sugar: snapshot.data['sugar'],
      strength: snapshot.data['strength'],
    );
  }

  // get brews stream
  Stream<List<Brew>> get brewsdata{
    return brewCollection.snapshots().map(_brewListFromSnapshot);
  }

  //get user doc Stream
  Stream<UserData> get userData {
    return brewCollection.document(uid).snapshots().map(_userDataFromSnapshot);
  }
}